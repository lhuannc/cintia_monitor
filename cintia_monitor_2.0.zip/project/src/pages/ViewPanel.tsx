import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { Maximize2 } from 'lucide-react';
import { VitalCard } from '../components/VitalCard';

interface PanelBed {
  id: string;
  position: number;
  bed: {
    id: string;
    name: string;
    sector: string;
    device_serial: string | null;
  };
}

interface MonitorData {
  systolic_pressure: number | null;
  diastolic_pressure: number | null;
  heart_rate: number | null;
  respiratory_rate: number | null;
  o2_saturation: number | null;
  temperature_f: number | null;
  co2: number | null;
  record_date: string;
  patient_name: string;
  active_alarms: string[] | null;
}

export function ViewPanel() {
  const { id } = useParams<{ id: string }>();
  const [panelBeds, setPanelBeds] = useState<PanelBed[]>([]);
  const [loading, setLoading] = useState(true);
  const [monitorData, setMonitorData] = useState<Record<string, MonitorData>>({});
  const [isFullscreen, setIsFullscreen] = useState(false);

  useEffect(() => {
    fetchPanelBeds();
    const interval = setInterval(fetchMonitorData, 1000);
    return () => clearInterval(interval);
  }, [id]);

  async function fetchPanelBeds() {
    try {
      const { data, error } = await supabase
        .from('panel_beds')
        .select(`
          id,
          position,
          bed:beds (
            id,
            name,
            sector,
            device_serial
          )
        `)
        .eq('panel_id', id)
        .order('position');

      if (error) throw error;
      setPanelBeds(data || []);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching panel beds:', error);
      setLoading(false);
    }
  }

  async function fetchMonitorData() {
    try {
      const deviceSerials = panelBeds
        .map((pb) => pb.bed.device_serial)
        .filter((serial): serial is string => serial !== null);

      if (deviceSerials.length === 0) return;

      const { data, error } = await supabase
        .from('monitor_data')
        .select('*')
        .in('device_ip', deviceSerials)
        .order('record_date', { ascending: false })
        .limit(1);

      if (error) throw error;

      if (data) {
        const newMonitorData: Record<string, MonitorData> = {};
        data.forEach((record) => {
          newMonitorData[record.device_ip] = record;
        });
        setMonitorData(newMonitorData);
      }
    } catch (error) {
      console.error('Error fetching monitor data:', error);
    }
  }

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen();
      setIsFullscreen(false);
    }
  };

  if (loading) {
    return <div>Loading...</div>;
  }

  return (
    <div className={`min-h-screen bg-gray-900 p-4 ${isFullscreen ? 'fixed inset-0 z-50' : ''}`}>
      <div className="mb-4 flex justify-between items-center">
        <h1 className="text-2xl font-bold text-white">Panel View</h1>
        <button
          onClick={toggleFullscreen}
          className="rounded-md bg-blue-600 px-4 py-2 text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
        >
          <Maximize2 className="h-5 w-5" />
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 gap-4 auto-rows-fr">
        {panelBeds.map((panelBed) => {
          const data = panelBed.bed.device_serial 
            ? monitorData[panelBed.bed.device_serial]
            : null;

          return (
            <VitalCard
              key={panelBed.id}
              bedName={panelBed.bed.name}
              bedNumber={panelBed.position}
              patientName={data?.patient_name || 'Anônimo'}
              vitals={{
                systolic: data?.systolic_pressure || 0,
                diastolic: data?.diastolic_pressure || 0,
                mean: Math.round(((data?.systolic_pressure || 0) + 2 * (data?.diastolic_pressure || 0)) / 3),
                heartRate: data?.heart_rate || 0,
                respRate: data?.respiratory_rate || 0,
                spo2: data?.o2_saturation || 0,
                co2: data?.co2 || 0,
                temperature: data?.temperature_f 
                  ? ((data.temperature_f - 32) * 5/9).toFixed(1)
                  : null,
              }}
              alarms={data?.active_alarms || []}
              history={{
                heartRate: [],
                respRate: [],
                spo2: [],
                co2: []
              }}
            />
          );
        })}
      </div>
    </div>
  );
}