import React, { useEffect, useRef } from 'react';
import clsx from 'clsx';

interface VitalCardProps {
  bedName: string;
  bedNumber: number;
  patientName: string;
  vitals: {
    systolic: number;
    diastolic: number;
    mean: number;
    heartRate: number;
    respRate: number;
    spo2: number;
    co2: number;
    temperature: string | null;
  };
  alarms?: string[];
  history?: {
    heartRate: number[];
    respRate: number[];
    spo2: number[];
    co2: number[];
  };
}

function getStatusColor(value: number, type: 'bp' | 'hr' | 'rr' | 'spo2' | 'temp' | 'co2'): string {
  switch (type) {
    case 'bp':
      if (value < 90) return 'text-red-500';
      if (value > 140) return 'text-yellow-500';
      return 'text-green-500';
    case 'hr':
      if (value < 60 || value > 100) return 'text-red-500';
      if (value < 70 || value > 90) return 'text-yellow-500';
      return 'text-green-500';
    case 'rr':
      if (value < 12 || value > 25) return 'text-red-500';
      if (value < 14 || value > 20) return 'text-yellow-500';
      return 'text-green-500';
    case 'spo2':
      if (value < 90) return 'text-red-500';
      if (value < 95) return 'text-yellow-500';
      return 'text-green-500';
    case 'co2':
      if (value < 35 || value > 45) return 'text-red-500';
      if (value < 38 || value > 42) return 'text-yellow-500';
      return 'text-green-500';
    default:
      return 'text-gray-500';
  }
}

function VitalGraph({ color, animate = true }: { color: string; animate?: boolean }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = canvas.offsetWidth * window.devicePixelRatio;
    canvas.height = canvas.offsetHeight * window.devicePixelRatio;
    ctx.scale(window.devicePixelRatio, window.devicePixelRatio);

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    ctx.beginPath();
    ctx.strokeStyle = color;
    ctx.lineWidth = 1.5;

    if (animate) {
      let x = 0;
      const amplitude = 10;
      const frequency = 0.05;
      const baseY = canvas.offsetHeight / 2;

      function draw() {
        ctx.clearRect(0, 0, canvas.offsetWidth, canvas.offsetHeight);
        ctx.beginPath();
        ctx.moveTo(0, baseY);

        for (let i = 0; i < canvas.offsetWidth; i++) {
          const y = baseY + Math.sin((i + x) * frequency) * amplitude;
          ctx.lineTo(i, y);
        }

        ctx.stroke();
        x += 1;
        requestAnimationFrame(draw);
      }

      draw();
    } else {
      const y = canvas.offsetHeight / 2;
      ctx.moveTo(0, y);
      ctx.lineTo(canvas.offsetWidth, y);
      ctx.stroke();
    }
  }, [color, animate]);

  return (
    <canvas
      ref={canvasRef}
      className="w-full h-full"
      style={{ height: '32px' }}
    />
  );
}

function getInitials(name: string): string {
  return name
    .split(' ')
    .map(part => part[0])
    .join('')
    .toUpperCase();
}

export function VitalCard({ 
  bedName, 
  bedNumber, 
  patientName, 
  vitals, 
  alarms = [], 
  history = {
    heartRate: [],
    respRate: [],
    spo2: [],
    co2: []
  }
}: VitalCardProps) {
  return (
    <div className="bg-gray-900 rounded-lg overflow-hidden border border-gray-800">
      {/* Header Section - Patient Info */}
      <div className="border-b border-gray-800 p-4">
        <div className="flex items-center justify-between">
          <div>
            <div className="text-gray-400 text-sm">Patient ID: {bedNumber}</div>
            <div className="text-xl font-bold text-white">{getInitials(patientName)}</div>
          </div>
          <div className="text-right">
            <div className="text-gray-400 text-sm">Bed</div>
            <div className="text-lg font-semibold text-cyan-500">{bedName}</div>
          </div>
        </div>
      </div>

      {/* Vital Signs Section */}
      <div className="p-4 space-y-4">
        {/* First Row */}
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-1">
            <div className="flex justify-between items-center">
              <span className="text-yellow-500 text-sm font-medium">PNI</span>
              <span className={clsx("text-xl font-bold", getStatusColor(vitals.systolic, 'bp'))}>
                {vitals.systolic}/{vitals.diastolic}
              </span>
            </div>
            <div className="h-8">
              <VitalGraph color="#EAB308" animate={history.heartRate.length > 0} />
            </div>
          </div>
          <div className="space-y-1">
            <div className="flex justify-between items-center">
              <span className="text-yellow-500 text-sm font-medium">PAM</span>
              <span className={clsx("text-xl font-bold", getStatusColor(vitals.mean, 'bp'))}>
                {vitals.mean}
              </span>
            </div>
            <div className="h-8">
              <VitalGraph color="#EAB308" animate={history.heartRate.length > 0} />
            </div>
          </div>
        </div>

        {/* Second Row */}
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-1">
            <div className="flex justify-between items-center">
              <span className="text-green-500 text-sm font-medium">FC</span>
              <span className={clsx("text-xl font-bold", getStatusColor(vitals.heartRate, 'hr'))}>
                {vitals.heartRate}
              </span>
            </div>
            <div className="h-8">
              <VitalGraph color="#22C55E" animate={history.heartRate.length > 0} />
            </div>
          </div>
          <div className="space-y-1">
            <div className="flex justify-between items-center">
              <span className="text-blue-500 text-sm font-medium">RESP</span>
              <span className={clsx("text-xl font-bold", getStatusColor(vitals.respRate, 'rr'))}>
                {vitals.respRate}
              </span>
            </div>
            <div className="h-8">
              <VitalGraph color="#3B82F6" animate={history.respRate.length > 0} />
            </div>
          </div>
        </div>

        {/* Third Row */}
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-1">
            <div className="flex justify-between items-center">
              <span className="text-purple-500 text-sm font-medium">SpO₂</span>
              <span className={clsx("text-xl font-bold", getStatusColor(vitals.spo2, 'spo2'))}>
                {vitals.spo2}%
              </span>
            </div>
            <div className="h-8">
              <VitalGraph color="#A855F7" animate={history.spo2.length > 0} />
            </div>
          </div>
          <div className="space-y-1">
            <div className="flex justify-between items-center">
              <span className="text-red-500 text-sm font-medium">CO₂</span>
              <span className={clsx("text-xl font-bold", getStatusColor(vitals.co2, 'co2'))}>
                {vitals.co2}
              </span>
            </div>
            <div className="h-8">
              <VitalGraph color="#EF4444" animate={history.co2.length > 0} />
            </div>
          </div>
        </div>
      </div>

      {/* Footer - Alarms Section */}
      <div className="border-t border-gray-800 p-4">
        <div className="text-sm font-medium text-gray-400 mb-2">Alarms</div>
        {alarms.length > 0 ? (
          <div className="flex flex-wrap gap-2">
            {alarms.map((alarm, index) => (
              <span
                key={index}
                className="px-2 py-1 text-xs font-medium bg-red-500/20 text-red-500 rounded"
              >
                {alarm}
              </span>
            ))}
          </div>
        ) : (
          <div className="text-sm text-gray-500 opacity-70">No active alarms</div>
        )}
      </div>
    </div>
  );
}