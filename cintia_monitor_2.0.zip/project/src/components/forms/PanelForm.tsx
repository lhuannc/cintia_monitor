import React, { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { supabase } from '../../lib/supabase';

interface Bed {
  id: string;
  name: string;
  sector: string;
}

const panelSchema = z.object({
  name: z.string().min(1, 'Name is required'),
});

type PanelFormData = z.infer<typeof panelSchema>;

interface PanelFormProps {
  onSuccess?: () => void;
}

export function PanelForm({ onSuccess }: PanelFormProps) {
  const [beds, setBeds] = useState<Bed[]>([]);
  const [selectedBeds, setSelectedBeds] = useState<Array<{ id: string; position: number }>>([]);
  const [error, setError] = useState<string | null>(null);

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors, isSubmitting },
  } = useForm<PanelFormData>({
    resolver: zodResolver(panelSchema),
  });

  useEffect(() => {
    async function fetchBeds() {
      try {
        const { data, error } = await supabase.from('beds').select('*');
        if (error) throw error;
        setBeds(data || []);
      } catch (error) {
        console.error('Error fetching beds:', error);
        setError('Failed to fetch beds');
      }
    }
    fetchBeds();
  }, []);

  const onSubmit = async (data: PanelFormData) => {
    try {
      setError(null);
      
      // Create the panel first
      const { data: panel, error: panelError } = await supabase
        .from('panels')
        .insert([{ name: data.name }])
        .select()
        .single();

      if (panelError) throw panelError;

      // Then create the panel_beds entries
      if (selectedBeds.length > 0) {
        const panelBeds = selectedBeds.map((bed) => ({
          panel_id: panel.id,
          bed_id: bed.id,
          position: bed.position,
        }));

        const { error: bedsError } = await supabase
          .from('panel_beds')
          .insert(panelBeds);

        if (bedsError) throw bedsError;
      }

      reset();
      setSelectedBeds([]);
      onSuccess?.();
    } catch (error) {
      console.error('Error creating panel:', error);
      setError('Failed to create panel. Please try again.');
    }
  };

  const addBed = (bedId: string) => {
    if (!selectedBeds.some(bed => bed.id === bedId)) {
      setSelectedBeds(prev => [...prev, { 
        id: bedId, 
        position: prev.length + 1 
      }]);
    }
  };

  const removeBed = (bedId: string) => {
    setSelectedBeds(prev => {
      const filtered = prev.filter(bed => bed.id !== bedId);
      // Reposition remaining beds
      return filtered.map((bed, index) => ({
        ...bed,
        position: index + 1
      }));
    });
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
      {error && (
        <div className="rounded-md bg-red-50 p-4">
          <div className="flex">
            <div className="ml-3">
              <h3 className="text-sm font-medium text-red-800">{error}</h3>
            </div>
          </div>
        </div>
      )}

      <div>
        <label htmlFor="name" className="block text-sm font-medium text-gray-700">
          Panel Name
        </label>
        <input
          type="text"
          id="name"
          {...register('name')}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
        />
        {errors.name && (
          <p className="mt-1 text-sm text-red-600">{errors.name.message}</p>
        )}
      </div>

      <div>
        <h3 className="text-lg font-medium text-gray-900">Add Beds</h3>
        <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {beds.map((bed) => {
            const isSelected = selectedBeds.some((selected) => selected.id === bed.id);
            const position = selectedBeds.find(selected => selected.id === bed.id)?.position;
            
            return (
              <div
                key={bed.id}
                className="relative flex items-center space-x-3 rounded-lg border border-gray-300 bg-white px-6 py-5 shadow-sm focus-within:ring-2 focus-within:ring-blue-500 focus-within:ring-offset-2 hover:border-gray-400"
              >
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium text-gray-900">{bed.name}</p>
                  <p className="truncate text-sm text-gray-500">{bed.sector}</p>
                  {isSelected && (
                    <p className="mt-1 text-xs text-blue-600">Position: {position}</p>
                  )}
                </div>
                <button
                  type="button"
                  onClick={() => isSelected ? removeBed(bed.id) : addBed(bed.id)}
                  className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${
                    isSelected
                      ? 'bg-red-100 text-red-800 hover:bg-red-200'
                      : 'bg-blue-100 text-blue-800 hover:bg-blue-200'
                  }`}
                >
                  {isSelected ? 'Remove' : 'Add'}
                </button>
              </div>
            );
          })}
        </div>
      </div>

      <button
        type="submit"
        disabled={isSubmitting}
        className="w-full rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50"
      >
        {isSubmitting ? 'Creating...' : 'Create Panel'}
      </button>
    </form>
  );
}