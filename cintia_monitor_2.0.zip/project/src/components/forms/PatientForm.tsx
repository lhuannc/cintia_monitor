import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { supabase } from '../../lib/supabase';

interface Bed {
  id: string;
  name: string;
  sector: string;
}

const patientSchema = z.object({
  id: z.string().min(1, 'ID is required'),
  name: z.string().min(1, 'Name is required'),
  birth_date: z.string().min(1, 'Birth date is required'),
  gender: z.enum(['M', 'F', 'Other']),
  bed_id: z.string().optional(),
});

type PatientFormData = z.infer<typeof patientSchema>;

interface PatientFormProps {
  onSuccess?: () => void;
  initialData?: PatientFormData;
  mode?: 'create' | 'edit';
}

export function PatientForm({ onSuccess, initialData, mode = 'create' }: PatientFormProps) {
  const [beds, setBeds] = useState<Bed[]>([]);

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors, isSubmitting },
  } = useForm<PatientFormData>({
    resolver: zodResolver(patientSchema),
    defaultValues: initialData,
  });

  useEffect(() => {
    async function fetchBeds() {
      try {
        const { data, error } = await supabase
          .from('beds')
          .select('*')
          .order('name');
        if (error) throw error;
        setBeds(data || []);
      } catch (error) {
        console.error('Error fetching beds:', error);
      }
    }
    fetchBeds();
  }, []);

  const onSubmit = async (data: PatientFormData) => {
    try {
      if (mode === 'edit') {
        const { error } = await supabase
          .from('patients')
          .update(data)
          .eq('id', initialData?.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from('patients').insert([data]);
        if (error) throw error;
      }
      reset();
      onSuccess?.();
    } catch (error) {
      console.error('Error saving patient:', error);
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
      <div>
        <label htmlFor="id" className="block text-sm font-medium text-gray-700">
          Patient ID
        </label>
        <input
          type="text"
          id="id"
          disabled={mode === 'edit'}
          {...register('id')}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 disabled:bg-gray-100"
        />
        {errors.id && (
          <p className="mt-1 text-sm text-red-600">{errors.id.message}</p>
        )}
      </div>

      <div>
        <label htmlFor="name" className="block text-sm font-medium text-gray-700">
          Name
        </label>
        <input
          type="text"
          id="name"
          {...register('name')}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
        />
        {errors.name && (
          <p className="mt-1 text-sm text-red-600">{errors.name.message}</p>
        )}
      </div>

      <div>
        <label htmlFor="birth_date" className="block text-sm font-medium text-gray-700">
          Birth Date
        </label>
        <input
          type="date"
          id="birth_date"
          {...register('birth_date')}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
        />
        {errors.birth_date && (
          <p className="mt-1 text-sm text-red-600">{errors.birth_date.message}</p>
        )}
      </div>

      <div>
        <label htmlFor="gender" className="block text-sm font-medium text-gray-700">
          Gender
        </label>
        <select
          id="gender"
          {...register('gender')}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
        >
          <option value="M">Male</option>
          <option value="F">Female</option>
          <option value="Other">Other</option>
        </select>
        {errors.gender && (
          <p className="mt-1 text-sm text-red-600">{errors.gender.message}</p>
        )}
      </div>

      <div>
        <label htmlFor="bed_id" className="block text-sm font-medium text-gray-700">
          Bed
        </label>
        <select
          id="bed_id"
          {...register('bed_id')}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
        >
          <option value="">Select a bed</option>
          {beds.map((bed) => (
            <option key={bed.id} value={bed.id}>
              {bed.name} - {bed.sector}
            </option>
          ))}
        </select>
      </div>

      <button
        type="submit"
        disabled={isSubmitting}
        className="w-full rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50"
      >
        {isSubmitting ? 'Saving...' : mode === 'edit' ? 'Update Patient' : 'Create Patient'}
      </button>
    </form>
  );
}