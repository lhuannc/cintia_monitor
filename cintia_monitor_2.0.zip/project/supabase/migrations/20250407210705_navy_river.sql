/*
  # Add Alarm System

  1. New Tables
    - alarms
      - id (uuid, primary key)
      - protocol (text)
      - name (text)
      - parameter (text)
      - condition (text)
      - code (text)
      - created_at (timestamp)
      - updated_at (timestamp)

  2. Changes to monitor_data
    - Add co2 column for carbon dioxide monitoring
    - Add active_alarms column to store triggered alarms

  3. Security
    - Enable RLS on new tables
    - Add policies for authenticated users
*/

-- Add CO2 column to monitor_data
ALTER TABLE monitor_data
ADD COLUMN co2 INTEGER;

-- Add active_alarms column to monitor_data
ALTER TABLE monitor_data
ADD COLUMN active_alarms TEXT[];

-- Create alarms table
CREATE TABLE alarms (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  protocol TEXT NOT NULL,
  name TEXT NOT NULL,
  parameter TEXT NOT NULL,
  condition TEXT NOT NULL CHECK (condition IN ('gt', 'lt', 'eq')),
  code TEXT NOT NULL UNIQUE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create trigger for updated_at
CREATE TRIGGER set_updated_at
  BEFORE UPDATE ON alarms
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Enable RLS
ALTER TABLE alarms ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Enable read access for authenticated users"
  ON alarms FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Enable insert for authenticated users only"
  ON alarms FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Enable update for authenticated users"
  ON alarms FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Enable delete for authenticated users"
  ON alarms FOR DELETE
  TO authenticated
  USING (true);

-- Add parameter validation
ALTER TABLE alarms
ADD CONSTRAINT valid_parameter CHECK (
  parameter IN (
    'systolic_pressure',
    'diastolic_pressure',
    'mean_pressure',
    'heart_rate',
    'respiratory_rate',
    'o2_saturation',
    'temperature_f',
    'co2'
  )
);