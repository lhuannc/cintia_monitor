/*
  # Add patient-bed relationship

  1. Changes
    - Add bed_id column to patients table
    - Add foreign key constraint to link patients with beds
    - Add index for better query performance

  2. Security
    - Maintain existing RLS policies
*/

ALTER TABLE patients
ADD COLUMN bed_id UUID REFERENCES beds(id) ON DELETE SET NULL;

CREATE INDEX idx_patients_bed_id ON patients(bed_id);